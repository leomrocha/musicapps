//******************************************************************************
//
// Simple Base Library / YNBaseLib
//
// ��{���C�u����
//
// Copyright (C) 2010 WADA Masashi. All Rights Reserved.
//
//******************************************************************************

#include "stdafx.h"
#include "YNBaseLib.h"

