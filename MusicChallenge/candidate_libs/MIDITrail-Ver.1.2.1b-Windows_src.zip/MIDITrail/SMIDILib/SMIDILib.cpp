//******************************************************************************
//
// Simple MIDI Library / SMLib
//
// �V���v��MIDI���C�u����
//
// Copyright (C) 2010 WADA Masashi. All Rights Reserved.
//
//******************************************************************************

#include "stdafx.h"
#include "SMIDILib.h"

